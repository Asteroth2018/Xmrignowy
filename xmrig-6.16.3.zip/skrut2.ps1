$WScriptShell = New-Object -ComObject WScript.Shell
$TargetFile = "C:\ProgramFiles\x\rtm.cmd"
$ShortcutFile = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\rtm.lnk" 
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile  
$Shortcut.Save()